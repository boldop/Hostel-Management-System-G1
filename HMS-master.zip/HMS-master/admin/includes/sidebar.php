<style>
	a {
		color: white;
	}
</style>
<nav class="ts-sidebar">
	<ul class="ts-sidebar-menu">
		<br>
		<li class="ts-label" style="color:white;">Main</li>
		<li><a href="dashboard.php"><i class="fa fa-dashboard" style="color:white;"></i> Dashboard</a></li>
		<ul>

		</ul>
		</li>
		<li><a href="#"><i class="fa fa-desktop" style="color:white;"></i> Rooms</a>
			<ul>
				<li><a href="create-room.php" style="color:white;">Add a Room</a></li>
				<li><a href="manage-rooms.php" style="color:white;">Manage Rooms</a></li>
			</ul>
		</li>

		<li><a href="registration.php"><i class="fa fa-user" style="color:white;"></i>Resident Registration</a></li>
		<li><a href="manage-students.php"><i class="fa fa-users" style="color:white;"></i>Manage Students</a></li>
		<li><a href="approve_users.php"><i class="fa fa-check" style="color:white;"></i>Verify Students</a></li>

</nav>
